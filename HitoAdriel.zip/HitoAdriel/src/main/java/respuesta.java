import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/")
public class respuesta extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       
        String nombre = request.getParameter("nombre");
        int telefono = Integer.parseInt(request.getParameter("telefono"));
        String correo = request.getParameter("correo");
        String costoEntrenamientos = request.getParameter("plan");
        String peso = request.getParameter("peso");
        String eventos = request.getParameter("eventos");
        int horasExtra = Integer.parseInt(request.getParameter("horasExtra"));
       
        //Calculo de costos
       
        double costoEntrenamientosEuros = 0.0;
        if(costoEntrenamientos.equals("principiante")) {
            costoEntrenamientosEuros = 25.0;
        } else if(costoEntrenamientos.equals("intermedio")) {
            costoEntrenamientosEuros = 30.0;
        } else if(costoEntrenamientos.equals("elite")) {
            costoEntrenamientosEuros = 35.0;
        } else if(costoEntrenamientos.equals("privado")) {
            costoEntrenamientosEuros = 9.50;
        } else if(costoEntrenamientos.equals("competicion")) {
            costoEntrenamientosEuros = 22.0;
        }
       
        double costoHorasExtra = 0.0;
        if(horasExtra == 1) {
            costoHorasExtra = 5.0;
        } else if(horasExtra == 2) {
            costoHorasExtra = 10.0;
        } else if(horasExtra == 3) {
            costoHorasExtra = 15.0;
        } else if(horasExtra == 4) {
            costoHorasExtra = 20.0;
        } else if(horasExtra == 5) {
            costoHorasExtra = 25.0;
        }
       

        // Calcular costo total
           double costoTotal = costoEntrenamientosEuros;

           switch (horasExtra) {
               case 1:
                   costoTotal += 5.0;
                   break;
               case 2:
                   costoTotal += 10.0;
                   break;
               case 3:
                   costoTotal += 15.0;
                   break;
               case 4:
                   costoTotal += 20.0;
                   break;
               case 5:
                   costoTotal += 25.0;
                   break;
               default:
                   break;
           }
       
       
        //Impresion de resultados
       
           out.println("<html><head><title>Datos del formulario</title>");
           out.println("<style>");
           out.println("table {border-collapse: collapse; width: 100%;}");
           out.println("th, td {text-align: left; padding: 12px;}");
           out.println("th {background-color: #0000ff; color: white; font-weight: bold; text-transform: uppercase;}");
           out.println("tr:nth-child(even) {background-color: #f2f2f2;}");
           out.println(".container {max-width: 700px; margin: 0 auto; padding: 40px; font-family: Arial, sans-serif;}");
           out.println(".title {font-size: 24px; margin-bottom: 24px;}");
           out.println(".label {width: 30%;}");
           out.println(".table {background-color: #e0e0e0;}");
           out.println("</style>");
           out.println("</head><body>");
           out.println("<div class='container'>");
           out.println("<h1 class='title'>Datos del formulario:</h1>");
           out.println("<table class='table'>");
           out.println("<tr><th class='label'>Nombre:</th><td>" + nombre + "</td></tr>");
           out.println("<tr><th class='label'>Teléfono:</th><td>" + telefono + "</td></tr>");
           out.println("<tr><th class='label'>Correo:</th><td>" + correo + "</td></tr>");
           out.println("<tr><th class='label'>Costo de entrenamientos:</th><td>" + costoEntrenamientosEuros + " euros</td></tr>");
           out.println("<tr><th class='label'>Peso:</th><td>" + peso + "</td></tr>");
           out.println("<tr><th class='label'>Eventos a los que ha asistido:</th><td>" + eventos + "</td></tr>");
           out.println("<tr><th class='label'>Costo de horas extra al mes:</th><td>" + costoHorasExtra + " euros</td></tr>");
           out.println("<tr><th class='label'>Costo total:</th><td>" + costoTotal + " euros</td></tr>");
           out.println("</table>");
           out.println("</div>");
           out.println("</body></html>");



       
       
   
}
}